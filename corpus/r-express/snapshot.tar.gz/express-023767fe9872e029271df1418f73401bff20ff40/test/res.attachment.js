'use strict'

const { Buffer } = require('node:buffer');

var express = require('../')
  , request = require('supertest');

describe('res', function(){
  describe('.attachment()', function(){
    it('should Content-Disposition to attachment', function(done){
      var app = express();

      app.use(function(req, res){
        res.attachment().send('foo');
      });

      request(app)
      .get('/')
      .expect('Content-Disposition', 'attachment', done);
    })
  })

  describe('.attachment(filename)', function(){
    it('should add the filename param', function(done){
      var app = express();

      app.use(function(req, res){
        res.attachment('/path/to/image.png');
        res.send('foo');
      });

      request(app)
      .get('/')
      .expect('Content-Disposition', 'attachment; filename=image.png', done);
    })

    it('should quote file names that are not a valid token', function(done){
      var app = express();

      app.use(function(req, res){
        res.attachment('/path/to/my report.png');
        res.send('foo');
      });

      request(app)
      .get('/')
      .expect('Content-Disposition', 'attachment; filename="my report.png"', done);
    })

    it('should handle an empty file name', function(done){
      var app = express();

      app.use(function(req, res){
        res.attachment('');
        res.send('foo');
      });

      request(app)
      .get('/')
      .expect('Content-Disposition', 'attachment; filename=""', done);
    })

    it('should set the Content-Type', function(done){
      var app = express();

      app.use(function(req, res){
        res.attachment('/path/to/image.png');
        res.send(Buffer.alloc(4, '.'))
      });

      request(app)
      .get('/')
      .expect('Content-Type', 'image/png', done);
    })
  })

  describe('.attachment(utf8filename)', function(){
    it('should add the filename and filename* params', function(done){
      var app = express();

      app.use(function(req, res){
        res.attachment('/locales/日本語.txt');
        res.send('japanese');
      });

      request(app)
      .get('/')
      .expect('Content-Disposition', 'attachment; filename="???.txt"; filename*=UTF-8\'\'%E6%97%A5%E6%9C%AC%E8%AA%9E.txt')
      .expect(200, done);
    })

    it('should encode latin1 file names with an ASCII fallback and filename* param', function(done){
      var app = express();

      app.use(function(req, res){
        res.attachment('/locales/café.txt');
        res.send('coffee');
      });

      request(app)
      .get('/')
      .expect('Content-Disposition', 'attachment; filename="caf?.txt"; filename*=UTF-8\'\'caf%C3%A9.txt')
      .expect(200, done);
    })

    it('should set the Content-Type', function(done){
      var app = express();

      app.use(function(req, res){
        res.attachment('/locales/日本語.txt');
        res.send('japanese');
      });

      request(app)
      .get('/')
      .expect('Content-Type', 'text/plain; charset=utf-8', done);
    })
  })
})
