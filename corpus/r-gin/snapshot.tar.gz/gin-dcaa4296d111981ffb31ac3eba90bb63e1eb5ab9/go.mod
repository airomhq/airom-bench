module github.com/gin-gonic/gin

go 1.25.0

require (
	github.com/bytedance/sonic v1.15.0
	github.com/gin-contrib/sse v1.1.0
	github.com/go-playground/validator/v10 v10.30.3
	github.com/goccy/go-json v0.10.6
	github.com/goccy/go-yaml v1.19.2
	github.com/json-iterator/go v1.1.12
	github.com/mattn/go-isatty v0.0.20
	github.com/modern-go/reflect2 v1.0.2
	github.com/pelletier/go-toml/v2 v2.2.4
	github.com/quic-go/quic-go v0.60.0
	github.com/stretchr/testify v1.11.1
	github.com/ugorji/go/codec v1.3.1
	go.mongodb.org/mongo-driver/v2 v2.5.0
	golang.org/x/net v0.56.0
	google.golang.org/protobuf v1.36.11
)

require gopkg.in/yaml.v3 v3.0.1 // indirect

require (
	github.com/bytedance/gopkg v0.1.3 // indirect
	github.com/bytedance/sonic/loader v0.5.0 // indirect
	github.com/cloudwego/base64x v0.1.6 // indirect
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/gabriel-vasile/mimetype v1.4.13 // indirect
	github.com/go-playground/locales v0.14.1 // indirect
	github.com/go-playground/universal-translator v0.18.1 // indirect
	github.com/klauspost/cpuid/v2 v2.3.0 // indirect
	github.com/kr/text v0.2.0 // indirect
	github.com/leodido/go-urn v1.4.0 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/quic-go/qpack v0.6.0 // indirect
	github.com/twitchyliquid64/golang-asm v0.15.1 // indirect
	go.uber.org/mock v0.6.0 // indirect
	golang.org/x/arch v0.25.0 // indirect
	golang.org/x/crypto v0.53.0 // indirect
	golang.org/x/sys v0.46.0 // indirect
	golang.org/x/text v0.39.0 // indirect
)
